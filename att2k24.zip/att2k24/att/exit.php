<?php

header("Location: https://www.att.com/");

?>